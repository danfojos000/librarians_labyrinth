import pygame
from pygame import mixer
import random
import csv
from bullet import Bullet
import asyncio

pygame.init()
mixer.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = int(SCREEN_WIDTH * 0.8)

EDITOR_PANEL = 0
screen = pygame.display.set_mode((SCREEN_WIDTH + EDITOR_PANEL, SCREEN_HEIGHT))
pygame.display.set_caption('The Librarian\'s Labyrinth' )

# set framerate
clock = pygame.time.Clock()
FPS = 120

# define game variables
GRAVITY = 0.75
SCROLL_THRESH = 200
ROWS = 16
COLS = 150
TILE_SIZE = SCREEN_HEIGHT // ROWS
TILE_TYPES = 135
MAX_LEVELS = 3
screen_scroll = 0
bg_scroll = 0
level = 1
start_game = True
start_intro = False

boss_battle = False
current_question = random.randint(0, 22)
player_answer = ""
show_result_timer = 0
question_result = ""
num_of_questions = 5  # How many questions the player has to answer correctly
correctly_answered = 0  # Is a counter for num_of_questions

questions = [
    {
        "question": "___ is sensory details appealing to the five senses",
        "answer": "imagery"
    },
    {
        "question": "___ is same consonant sounds at the beginning of two or more words",
        "answer": "alliteration"
    },
    {
        "question": "___ is an exaggeration or overstatement",
        "answer": "hyperbole"
    },
    {
        "question": "___ is same consonant sounds at the beginning of two or more words",
        "answer": "alliteration"
    },
    {
        "question": "___ is the main idea or underlying meaning of a literary work",
        "answer": "theme"
    },
    {
        "question": "___ is the methods an author uses to develop the qualities and personalities of characters in a story",
        "answer": "characterization"
    },
    {
        "question": "___ is a judgment based on reasoning rather than on direct statement",
        "answer": "inference"
    },
    {
        "question": "___ is the use of “hints” of events to come",
        "answer": "foreshadowing"
    },
    {
        "question": "___ is a series of related events which bring about the resolution of some conflict or problem",
        "answer": "plot"
    },
    {
        "question": "___ is the time and place in which the events of a narrative occur",
        "answer": "setting"
    },
    {
        "question": "___ is the author’s choice of narrator for a story",
        "answer": "POV"
    },
    {
        "question": "___ is an author’s attitude toward his/her subject matter",
        "answer": "tone"
    },
    {
        "question": "___ is the climate of feeling within a literary work",
        "answer": "mood"
    },
    {
        "question": "___ is a character that parallels the main character but is used to show contrast between the two characters",
        "answer": "foil"
    },
    {
        "question": "___ is a word, phrase, or object in a work of literature that signifies something beyond itself",
        "answer": "symbol"
    },
    {
        "question": "___ is a sudden perception that causes a character to change or act in a certain way",
        "answer": "epiphany"
    },
    {
        "question": "___ is word choice",
        "answer": "diction"
    },
    {
        "question": "___ is the problem, issue, or struggle in a story that triggers the action internal or external ___",
        "answer": "conflict"
    },
    {
        "question": "___ is the main character who holds the main focus of the story",
        "answer": "protagonist"
    },
    {
        "question": "___ is a rival or adversary that attempts to work against the protagonist",
        "answer": "antagonist"
    },
    {
        "question": "___ is a character that doesn’t change",
        "answer": "static character"
    },
    {
        "question": "___ is a character that changes",
        "answer": "dynamic character"
    }
]

# editor variables
editor_mode = False
current_tile = 0
scroll_left = False
scroll_right = False
scroll_speed = 20
palette_scroll = 0
PALETTE_SCROLL_SPEED = 45

# define player action variables
moving_left = False
moving_right = False
moving_up = False
moving_down = False
shoot = False
grenade = False
grenade_thrown = False

# load music and sounds
# Background
# load layered ambient music
dungeon_air = pygame.mixer.Sound('audio/dungeon_air.ogg')
dungeon_ambience = pygame.mixer.Sound('audio/dungeon_ambience.ogg')
jump_fx = pygame.mixer.Sound('audio/jump.ogg')
shot_fx = pygame.mixer.Sound('audio/shot.ogg')
grenade_fx = pygame.mixer.Sound('audio/grenade.ogg')
dungeon_air.set_volume(1)
dungeon_ambience.set_volume(1)
jump_fx.set_volume(0.25)
shot_fx.set_volume(0.25)
grenade_fx.set_volume(0.25)
dungeon_air.play(-1)
dungeon_ambience.play(-1)

# load images
# button images
start_img = pygame.image.load('img/start_btn.png').convert_alpha()
exit_img = pygame.image.load('img/exit_btn.png').convert_alpha()
restart_img = pygame.image.load('img/restart_btn.png').convert_alpha()
# store tiles in a list
img_list = []
for x in range(TILE_TYPES):
    img = pygame.image.load(f'img/tile/{x}F.png')
    img = pygame.transform.scale(img, (TILE_SIZE, TILE_SIZE))
    img_list.append(img)
# store bullets in a list
alphabet_list = []
for x in range(27):  # 27 because there are 27 letters in the alphabet
    img = pygame.image.load(f'img/icons/bullet/{x}F.png')
    # img = pygame.transform.scale(img, (TILE_SIZE, TILE_SIZE))
    alphabet_list.append(img)
# grenade
grenade_img = pygame.image.load('img/icons/grenade.png').convert_alpha()
grenade_img = pygame.transform.scale(grenade_img, (51.2, 48.7))
# pick up boxes
health_box_img = pygame.transform.scale(pygame.image.load('img/icons/health_box.png').convert_alpha(), (TILE_SIZE, TILE_SIZE))
ammo_box_img = pygame.transform.scale(pygame.image.load('img/icons/ammo_box.png').convert_alpha(), (TILE_SIZE, TILE_SIZE))
grenade_box_img = pygame.transform.scale(pygame.image.load('img/icons/grenade_box.png').convert_alpha(), (TILE_SIZE, TILE_SIZE))
item_boxes = {
    'Health': health_box_img,
    'Ammo': ammo_box_img,
    'Grenade': grenade_box_img
}

# define colours
BG = (24, 20, 37)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
PINK = (235, 65, 54)

# define font
font = pygame.font.SysFont('Futura', 20)

def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))
def draw_grid():
    # vertical lines
    for c in range(COLS + 1):
        pygame.draw.line(screen, WHITE,
                         (c * TILE_SIZE - bg_scroll, 0),
                         (c * TILE_SIZE - bg_scroll, SCREEN_HEIGHT))

    # horizontal lines
    for r in range(ROWS + 1):
        pygame.draw.line(screen, WHITE,
                         (0, r * TILE_SIZE),
                         (SCREEN_WIDTH, r * TILE_SIZE))
def reset_level():
    enemy_group.empty()
    bullet_group.empty()
    grenade_group.empty()
    explosion_group.empty()
    item_box_group.empty()
    decoration_group.empty()
    water_group.empty()
    exit_group.empty()
    ladder_group.empty()
    wood_platform_group.empty()
    breakable_block_group.empty()
    boss_group.empty()

    data = []
    for row in range(ROWS):
        r = [-1] * COLS
        data.append(r)

    return data
def save_level(data, level_num):
    with open(f'level{level_num}_data.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        for row in data:
            writer.writerow(row)
def load_level(level_num):
    data = []
    for row in range(ROWS):
        r = [-1] * COLS
        data.append(r)

    with open(f'level{level_num}_data.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for x, row in enumerate(reader):
            for y, tile in enumerate(row):
                data[x][y] = int(tile)

    return data
def draw_question_box():
    pygame.draw.rect(screen, BLACK, (100, 150, 600, 300))
    pygame.draw.rect(screen, WHITE, (100, 150, 600, 300), 4)

    question_text = questions[current_question]["question"]

    draw_text("BOSS QUESTION!", font, RED, 300, 180)

    draw_text(question_text, font, WHITE, 140, 250)

    draw_text("Answer: " + player_answer, font, GREEN, 140, 320)

    draw_text(question_result, font, PINK, 140, 380)

    draw_text(str(correctly_answered) + " out of " + str(num_of_questions), font, WHITE, 300, 230)

# button class
class Button:
    def __init__(self, x, y, image, scale):
        width = image.get_width()
        height = image.get_height()
        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False

    def draw(self, surface):
        action = False

        # get mouse position
        pos = pygame.mouse.get_pos()

        # check mouseover and clicked conditions
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                action = True
                self.clicked = True

        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False

        # draw button
        surface.blit(self.image, (self.rect.x, self.rect.y))

        return action
class Soldier(pygame.sprite.Sprite):
    def __init__(self, char_type, x, y, scale, speed, ammo, grenades, health, bullet_damage=5):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.char_type = char_type
        self.speed = speed
        self.ammo = ammo
        self.start_ammo = ammo
        self.shoot_cooldown = 0
        self.grenades = grenades
        self.health = health
        self.max_health = self.health
        self.direction = 1
        self.vel_y = 0
        self.jump = False
        self.in_air = True
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()
        self.bullet_damage = bullet_damage
        # ai specific variables
        self.move_counter = 0
        self.vision = pygame.Rect(0, 0, 200, 20)
        self.idling = False
        self.idling_counter = 0
        self.hurt_timer = 0

        # load all images for the players
        animation_types = ['attack', 'hurt', 'idle', 'walk', 'run']

        for animation in animation_types:
            # reset temporary list of images
            temp_list = []
            # count number of files in the folder
            num_of_frames = 0
            while True:
                path = f'img/sprites/{self.char_type}/{animation}/{num_of_frames}.png'

                try:
                    pygame.image.load(path)
                    num_of_frames += 1
                except:
                    break
            for i in range(num_of_frames):
                img = pygame.image.load(f'img/sprites/{self.char_type}/{animation}/{i}.png').convert_alpha()
                img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))

                # Flip enemy sprites horizontally at load time
                if self.char_type != 'player':
                    img = pygame.transform.flip(img, True, False)
                # Crop transparent whitespace
                trimmed_rect = img.get_bounding_rect()
                img = img.subsurface(trimmed_rect).copy()

                temp_list.append(img)
            self.animation_list.append(temp_list)

        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.width = self.image.get_width()
        self.height = self.image.get_height()

    def update(self, dt):
        # track previous health to detect a new hit
        if not hasattr(self, '_last_health'):
            self._last_health = self.health

        if self.health < self._last_health:
            self.hurt_timer = 30  # hold hurt animation for 30 ticks
        self._last_health = self.health

        if self.hurt_timer > 0:
            self.update_action(1)  # 1: hurt
            self.hurt_timer -= 1 * dt

        self.update_animation(dt)
        self.check_alive()
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1 * dt

    def move(self, moving_left, moving_right, dt):
        # reset movement variables
        screen_scroll = 0
        dx = 0
        dy = 0

        # assign movement variables if moving left or right
        if moving_left:
            dx = -self.speed * dt
            self.flip = True
            self.direction = -1
        if moving_right:
            dx = self.speed * dt
            self.flip = False
            self.direction = 1

        # jump
        if self.jump == True and self.in_air == False:
            self.vel_y = -14
            self.jump = False
            self.in_air = True

        self.climbing = False

        for ladder in ladder_group:
            if ladder.rect.colliderect(self.rect):
                self.climbing = True

        # ladder movement
        if self.climbing:

            self.in_air = False
            self.vel_y = 0

            if moving_up:
                dy = -4 * dt

            if moving_down:
                dy = 4 * dt

        else:
            # normal gravity
            self.vel_y += GRAVITY * dt

            if self.vel_y > 10:
                self.vel_y = 10

            dy += self.vel_y * dt

        # check collision with obstacles
        for tile in world.obstacle_list:
            # check for collision in x direction
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0

            # check for collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                # check if bellow the ground i.e. jumping
                if self.vel_y < 0:
                    self.vel_y = 0
                    dy = tile[1].bottom - self.rect.top
                # check if above the ground i.e. falling
                elif self.vel_y >= 0:
                    self.vel_y = 0
                    self.in_air = False
                    dy = tile[1].top - self.rect.bottom

        # wood platform collision
        for platform in wood_platform_group:

            if platform.rect.colliderect(
                    self.rect.x,
                    self.rect.y + dy,
                    self.width,
                    self.height
            ):

                # only collide while falling
                if self.vel_y >= 0:

                    # player was above platform
                    if self.rect.bottom <= platform.rect.top + 10:
                        self.vel_y = 0
                        self.in_air = False

                        dy = platform.rect.top - self.rect.bottom

        # check for collision with water
        for water in water_group:

            if self.rect.colliderect(water.hitbox):
                self.health = 0

        # check for collision with exit
        level_complete = False
        if pygame.sprite.spritecollide(self, exit_group, False):
            level_complete = True

        # check if fallen of the map
        if self.rect.bottom > SCREEN_HEIGHT:
            self.health = 0
        # check if on top of the map
        if self.rect.top < 0:
            self.health = 0

        # check if going of the edges of the screen
        if self.char_type == 'player':
            if self.rect.left + dx < 0 or self.rect.right + dx > SCREEN_WIDTH:
                dx = 0

        # update rectangle position
        self.rect.x += dx
        self.rect.y += dy

        # update scroll based on player position
        if self.char_type == 'player':
            if (self.rect.right > SCREEN_WIDTH - SCROLL_THRESH and bg_scroll < (world.level_length * TILE_SIZE) - SCREEN_WIDTH)\
                    or (self.rect.left < SCROLL_THRESH and bg_scroll > abs(dx)):
                self.rect.x -= dx
                screen_scroll = -dx

        return screen_scroll, level_complete

    def shoot(self):
        if (self.shoot_cooldown <= 0) and (self.ammo > 0):
            self.shoot_cooldown = 20
            bullet = Bullet(self.rect.centerx + (0.75 * self.rect.size[0] * self.direction), self.rect.centery, self.direction, alphabet_list, self.bullet_damage)
            bullet_group.add(bullet)
            # reduce ammo
            self.ammo -= 1
            shot_fx.play()

    def ai(self, dt):
        if self.alive and player.alive:
            if self.idling == False and random.randint(1, 200) == 1:
                self.update_action(2)  # 2: idle
                self.idling = True
                self.idling_counter = 50

            if self.vision.colliderect(player.rect):
                # face the player
                if player.rect.centerx < self.rect.centerx:
                    self.direction = -1
                    self.flip = True
                else:
                    self.direction = 1
                    self.flip = False

                # attack range: within 1 tile
                if abs(self.rect.centerx - player.rect.centerx) < TILE_SIZE:
                    self.update_action(0)  # 0: attack
                    self.shoot()
                else:
                    # chase — walk toward the player
                    self.update_action(4)  # 3: Run
                    if player.rect.centerx < self.rect.centerx:
                        self.rect.x -= self.speed
                    else:
                        self.rect.x += self.speed
            else:
                if not self.idling:
                    if self.direction == 1:
                        ai_moving_right = True
                        self.rect.x += self.speed
                    else:
                        self.rect.x -= self.speed
                        ai_moving_right = False
                    ai_moving_left = not ai_moving_right
                    self.move(ai_moving_left, ai_moving_right, dt)
                    self.update_action(3)  # 3: walk
                    self.move_counter += 1 * dt

                    if self.move_counter > TILE_SIZE:
                        self.direction *= -1
                        self.move_counter *= -1
                else:
                    self.idling_counter -= 1 * dt
                    if self.idling_counter <= 0:
                        self.idling = False

        # keep vision centred on enemy
        self.vision.center = (self.rect.centerx + 75 * self.direction, self.rect.centery)

        # scroll
        self.rect.x += screen_scroll

    def update_animation(self, dt):
        ANIMATION_COOLDOWN = 100 * dt
        old_center = self.rect.center  # save position before swapping image
        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = old_center  # restore so sprite doesn't drift
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        if self.frame_index >= len(self.animation_list[self.action]):
            self.frame_index = 0

    def update_action(self, new_action):
        # check if the new action is different to the previous one
        if new_action != self.action:
            self.action = new_action
            # update the animation settings
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.speed = 0
            self.alive = False
            self.update_action(3)

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)
class Boss(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load('img/lich.png')
        self.image = pygame.transform.scale(self.image, (TILE_SIZE * 2.5, TILE_SIZE * 3))

        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

        self.defeated = False

    def update(self):
        global boss_battle

        self.rect.x += screen_scroll

        if self.rect.colliderect(player.rect) and not self.defeated:
            boss_battle = True

    def draw(self):
        screen.blit(self.image, self.rect)
class World:
    def __init__(self):
        self.obstacle_list = []

    def process_data(self, data):
        self.level_length = len(data[0])
        player_obj = None
        health_bar_obj = None
        # iterate through each value in level data file
        for y, row in enumerate(data):
            for x, tile in enumerate(row):
                if tile >= 0:
                    img = img_list[tile]
                    img_rect = img.get_rect()
                    img_rect.x = x * TILE_SIZE
                    img_rect.y = y * TILE_SIZE
                    tile_data = (img, img_rect, tile)
                    if 0 <= tile <= 44:
                        self.obstacle_list.append(tile_data)
                    elif 45 <= tile <= 56:
                        water = Water(img, x * TILE_SIZE, y * TILE_SIZE)
                        water_group.add(water)
                    elif 57 <= tile <= 112:
                        decoration = Decoration(img, x * TILE_SIZE, y * TILE_SIZE)
                        decoration_group.add(decoration)
                    elif tile == 113:  # create player
                        player_obj = Soldier('player', x * TILE_SIZE, y * TILE_SIZE, 3, 5, 20, 5, 100)
                        health_bar_obj = HealthBar(10, 10, player_obj.health, player_obj.health)
                    elif tile == 114:  # create enemies
                        enemy = Soldier('soldier', x * TILE_SIZE, y * TILE_SIZE, 1.65, 2, 50, 0, 100)
                        enemy_group.add(enemy)
                    elif 115 <= tile <= 119:  # create ammo box
                        item_box = ItemBox('Ammo', x * TILE_SIZE, y * TILE_SIZE)
                        item_box_group.add(item_box)
                    elif 120 <= tile <= 123:  # create exit
                        exit = Exit(img, x * TILE_SIZE, y * TILE_SIZE)
                        exit_group.add(exit)
                    elif 124 <= tile <= 125:  # Create ladders
                        ladder = Ladder(img, x * TILE_SIZE, y * TILE_SIZE)
                        ladder_group.add(ladder)
                    elif 126 <= tile <= 128:  # Create ladders
                        wood_platform = WoodPlatform(img, x * TILE_SIZE, y * TILE_SIZE)
                        wood_platform_group.add(wood_platform)
                    elif tile == 129:
                        breakable_block = BreakableBlock(img, x * TILE_SIZE, y * TILE_SIZE)
                        breakable_block_group.add(breakable_block)
                        self.obstacle_list.append((img, breakable_block.rect, 129))
                    elif tile == 130:  # create enemies
                        enemy = Soldier('skeleton2', x * TILE_SIZE, y * TILE_SIZE, 1.75, 2, 100, 0, 100, bullet_damage=25)
                        enemy_group.add(enemy)
                    elif tile == 132:  # create enemies
                        enemy = Soldier('skeleton1', x * TILE_SIZE, y * TILE_SIZE, 1.65, 2, 50, 0, 100)
                        enemy_group.add(enemy)
                    elif tile == 134:
                        boss = Boss(x * TILE_SIZE, y * TILE_SIZE)
                        boss_group.add(boss)

        return player_obj, health_bar_obj

    def draw(self):
        for tile in self.obstacle_list:
            tile[1].x += screen_scroll
            screen.blit(tile[0], tile[1])
class Decoration(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += screen_scroll
class Ladder(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.image = img
        self.rect = self.image.get_rect()

        self.rect.topleft = (x, y)

    def update(self):
        self.rect.x += screen_scroll
class WoodPlatform(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.image = img
        self.rect = self.image.get_rect()

        self.rect.topleft = (x, y)

    def update(self):
        self.rect.x += screen_scroll
class BreakableBlock(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.image = img
        self.rect = self.image.get_rect()

        self.rect.topleft = (x, y)

    def update(self):
        pass
class Water(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.image = img

        # visual position
        self.rect = self.image.get_rect()
        self.rect.midtop = (
            x + TILE_SIZE // 2,
            y + (TILE_SIZE - self.image.get_height())
        )

        # collision rect (bottom half only)
        self.hitbox = pygame.Rect(
            self.rect.x,
            self.rect.y + self.rect.height // 2,
            self.rect.width,
            self.rect.height // 2
        )

    def update(self):

        self.rect.x += screen_scroll
        self.hitbox.x += screen_scroll
class Exit(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += screen_scroll
class ItemBox(pygame.sprite.Sprite):
    def __init__(self, item_type, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.item_type = item_type
        self.image = item_boxes[self.item_type]
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        # scroll
        self.rect.x += screen_scroll
        # check if the player has picked up the box
        if pygame.sprite.collide_rect(self, player):
            # check what kind of box it was
            if self.item_type == 'Health':
                player.health += 25
                if player.health > player.max_health:
                    player.health = player.max_health
            elif self.item_type == 'Ammo':
                player.ammo += 15
            elif self.item_type == 'Grenade':
                player.grenades += 3
            # delete the item box
            self.kill()
class HealthBar():
    def __init__(self, x, y, health, max_health):
        self.x = x
        self.y = y
        self.health = health
        self.max_health = max_health

    def draw(self, health):
        # update with new health
        self.health = health
        # calculate health ratio
        ratio = self.health / self.max_health
        pygame.draw.rect(screen, BLACK, (self.x - 2, self.y - 2, 154, 24))
        pygame.draw.rect(screen, RED, (self.x, self.y, 150, 20))
        pygame.draw.rect(screen, GREEN, (self.x, self.y, 150 * ratio, 20))
class Grenade(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.timer = 100
        self.vel_y = -11
        self.speed = 7
        self.image = grenade_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.direction = direction

    def update(self, dt):
        self.vel_y += GRAVITY * dt
        dx = self.direction * self.speed * dt
        dy = self.vel_y * dt

        # check for collision with world
        for tile in world.obstacle_list:
            # check collision with walls
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                self.direction *= -1
                dx = self.direction * self.speed
            # check for collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                self.speed = 0
                # check if bellow the ground i.e. thrown up
                if self.vel_y < 0:
                    self.vel_y = 0
                    dy = tile[1].bottom - self.rect.top
                # check if above the ground i.e. falling
                elif self.vel_y >= 0:
                    self.vel_y = 0
                    dy = tile[1].top - self.rect.bottom

        # update grenade position
        self.rect.x += dx + screen_scroll
        self.rect.y += dy

        # countdown timer
        self.timer -= 1
        if self.timer <= 0:
            self.kill()
            grenade_fx.play()
            explosion = Explosion(self.rect.x, self.rect.y, 1.5)
            explosion_group.add(explosion)
            # do damage to anyone that is nearby
            if abs(self.rect.centerx - player.rect.centerx) < TILE_SIZE * 2 and \
                    abs(self.rect.centery - player.rect.centery) < TILE_SIZE * 2:
                player.health -= 50
            for enemy in enemy_group:
                if abs(self.rect.centerx - enemy.rect.centerx) < TILE_SIZE * 2 and \
                        abs(self.rect.centery - enemy.rect.centery) < TILE_SIZE * 2:
                    enemy.health -= 50
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, scale):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for num in range(1, 6):
            img = pygame.image.load(f'img/explosion/exp{num}.png').convert_alpha()
            img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
            self.images.append(img)
        self.frame_index = 0
        self.image = self.images[self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.counter = 0


    def update(self, dt):
        # scroll
        self.rect.x += screen_scroll

        EXPLOSION_SPEED = 4 * dt
        # update explosion animation
        self.counter += 1 * dt

        if self.counter >= EXPLOSION_SPEED:
            self.counter = 0
            self.frame_index += 1
            # if the animation is complete then delete the explosion
            if self.frame_index >= len(self.images):
                self.kill()
            else:
                self.image = self.images[self.frame_index]
class ScreenFade:
    def __init__(self, direction, color, speed):
        self.direction = direction
        self.color = color
        self.speed = speed
        self.fade_counter = 0

    def fade(self):
        fade_complete = False
        self.fade_counter += self.speed
        if self.direction == 1:  # whole screen fade
            pygame.draw.rect(screen, self.color, (0 - self.fade_counter, 0, SCREEN_WIDTH // 2, SCREEN_HEIGHT))
            pygame.draw.rect(screen, self.color, (SCREEN_WIDTH // 2 + self.fade_counter, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.draw.rect(screen, self.color, (0, 0 - self.fade_counter, SCREEN_WIDTH, SCREEN_HEIGHT // 2))
            pygame.draw.rect(screen, self.color, (0, SCREEN_HEIGHT // 2 + self.fade_counter, SCREEN_WIDTH, SCREEN_HEIGHT))
        if self.direction == 2:  # vertical screen fade down
            pygame.draw.rect(screen, self.color, (0, 0, SCREEN_WIDTH, 0 + self.fade_counter))
        if self.fade_counter >= SCREEN_WIDTH:
            fade_complete = True

        return fade_complete

# create screen fade
intro_fade = ScreenFade(1, BLACK, 4)
death_fade = ScreenFade(2, PINK, 4)

# start button
start_button = Button(SCREEN_WIDTH // 2 - 130, SCREEN_HEIGHT // 2 - 150, start_img, 1)
exit_button = Button(SCREEN_WIDTH // 2 - 110, SCREEN_HEIGHT // 2 + 50, exit_img, 1)
restart_button = Button(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50, restart_img, 2)

tile_buttons = []

button_col = 0
button_row = 0

for i in range(TILE_TYPES):

    tile_img = pygame.transform.scale(img_list[i], (40, 40))

    x = SCREEN_WIDTH + 10 + (button_col * 45)
    y = 50 + (button_row * 45)

    tile_button = Button(x, y, tile_img, 1)

    tile_buttons.append(tile_button)

    button_col += 1

    if button_col == 3:
        button_col = 0
        button_row += 1

# create sprite groups
enemy_group = pygame.sprite.Group()
bullet_group = pygame.sprite.Group()
grenade_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()
item_box_group = pygame.sprite.Group()
decoration_group = pygame.sprite.Group()
water_group = pygame.sprite.Group()
exit_group = pygame.sprite.Group()
ladder_group = pygame.sprite.Group()
wood_platform_group = pygame.sprite.Group()
breakable_block_group = pygame.sprite.Group()
boss_group = pygame.sprite.Group()
async def main():
    global moving_left
    global moving_right
    global moving_up
    global moving_down
    global shoot
    global grenade
    global grenade_thrown
    global screen_scroll
    global bg_scroll
    global level
    global start_game
    global start_intro
    global editor_mode

    global world
    global player
    global health_bar
    global world_data
    global current_tile
    global palette_scroll
    global scroll_left
    global scroll_right
    global dungeon_air, dungeon_ambience, jump_fx, shot_fx, grenade_fx
    global boss_battle
    global current_question
    global player_answer
    global show_result_timer
    global question_result
    global num_of_questions
    global correctly_answered

    print("DEBUG: main() started")

    world_data = []
    for row in range(ROWS):
        r = [-1] * COLS
        world_data.append(r)

    print("DEBUG: loading CSV")
    try:
        with open(f'level{level}_data.csv', newline='') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for x, row in enumerate(reader):
                for y, tile in enumerate(row):
                    world_data[x][y] = int(tile)
        print("DEBUG: CSV loaded OK")
    except Exception as e:
        print(f"DEBUG: CSV failed: {e}")

    print("DEBUG: creating world")
    world = World()
    print("DEBUG: processing data")
    try:
        player, health_bar = world.process_data(world_data)
        print("DEBUG: world ready")
    except Exception as e:
        print(f"DEBUG: process_data failed: {e}")

    run = True
    print("DEBUG: entering game loop")

    while run:
        dt = clock.tick(FPS) / 1000 * 60

        if not start_game:
            # draw menu
            screen.fill(BG)
            # add buttons
            if start_button.draw(screen):
                start_game = True
                start_intro = True
            if exit_button.draw(screen):
                run = False
        else:
            screen.fill(BG)

            if editor_mode:
                draw_grid()

                # draw tiles manually
                for y, row in enumerate(world_data):
                    for x, tile in enumerate(row):
                        if tile >= 0:
                            screen.blit(img_list[tile],
                                        (x * TILE_SIZE - bg_scroll,
                                         y * TILE_SIZE))

                # tile selection panel
                pygame.draw.rect(screen, BLACK,
                                 (SCREEN_WIDTH, 0, EDITOR_PANEL, SCREEN_HEIGHT))

                # draw tile buttons
                for button_count, tile_button in enumerate(tile_buttons):

                    # move buttons based on scroll
                    tile_button.rect.y = (
                            50
                            + ((button_count // 3) * 45)
                            - palette_scroll
                    )

                    # only draw visible buttons
                    if -50 < tile_button.rect.y < SCREEN_HEIGHT:

                        if tile_button.draw(screen):
                            current_tile = button_count

                # highlight selected tile
                pygame.draw.rect(
                    screen,
                    RED,
                    tile_buttons[current_tile].rect,
                    3
                )

            else:
                world.draw()

                # update and draw groups
                bullet_group.update(screen_scroll, SCREEN_WIDTH, world, breakable_block_group, player, bullet_group, enemy_group, dt)
                grenade_group.update(dt)
                explosion_group.update(dt)
                item_box_group.update()
                decoration_group.update()
                ladder_group.update()
                wood_platform_group.update()
                breakable_block_group.update()
                water_group.update()
                exit_group.update()
                boss_group.update()
                bullet_group.draw(screen)
                grenade_group.draw(screen)
                explosion_group.draw(screen)
                item_box_group.draw(screen)
                decoration_group.draw(screen)
                ladder_group.draw(screen)
                wood_platform_group.draw(screen)
                water_group.draw(screen)
                exit_group.draw(screen)
                boss_group.draw(screen)

            # show player health
            health_bar.draw(player.health)
            # show ammo
            draw_text('AMMO: ', font, WHITE, 10, 35)
            for x in range(player.ammo):
                screen.blit(alphabet_list[random.randint(0, 26)], (90 + (x * 15), 40))
            # show grenades
            draw_text('Exploding Books: ', font, WHITE, 10, 60)
            for x in range(player.grenades):
                screen.blit(grenade_img, (160 + (x * 40), 50))

            player.update(dt)
            player.draw()

            for enemy in enemy_group:
                enemy.ai(dt)
                enemy.update(dt)
                enemy.draw()

            # show intro
            if start_intro:
                if intro_fade.fade():
                    start_intro = False
                    intro_fade.fade_counter = 0

            if boss_battle:
                draw_question_box()

                show_result_timer -= 1

                if show_result_timer <= 0 and question_result != "":
                    question_result = ""

                # stop normal gameplay movement/actions
                moving_left = False
                moving_right = False
                shoot = False

            # update player actions
            if player.alive:
                # shoot bullets
                if shoot:
                    player.shoot()
                # throw grenades
                elif grenade and grenade_thrown == False and player.grenades > 0:
                    grenade = Grenade(player.rect.centerx + (0.5 * player.rect.size[0] * player.direction),
                                      player.rect.top, player.direction)
                    grenade_group.add(grenade)
                    # reduce grenades
                    player.grenades -= 1
                    grenade_thrown = True
                if player.hurt_timer <= 0:
                    if moving_left or moving_right:
                        player.update_action(3)  # 1: run
                    else:
                        player.update_action(2)  # 0: idle
                screen_scroll, level_complete = player.move(moving_left, moving_right, dt)
                bg_scroll -= screen_scroll
                # check if player has complete the level
                if level_complete:
                    start_intro = True
                    level += 1
                    bg_scroll = 0
                    world_data = reset_level()
                    if level <= MAX_LEVELS:
                        # load in level data and create world
                        with open(f'level{level}_data.csv', newline='') as csvfile:
                            reader = csv.reader(csvfile, delimiter=',')
                            for x, row in enumerate(reader):
                                for y, tile in enumerate(row):
                                    world_data[x][y] = int(tile)
                        world = World()
                        player, health_bar = world.process_data(world_data)
                        boss_battle = False
                        current_question = random.randint(0, 22)
                        player_answer = ""
                        show_result_timer = 0
                        question_result = ""
            else:
                screen_scroll = 0
                if death_fade.fade():
                    if restart_button.draw(screen):
                        death_fade.fade_counter = 0
                        start_intro = True
                        bg_scroll = 0
                        world_data = reset_level()
                        # load in level data and create world
                        with open(f'level{level}_data.csv', newline='') as csvfile:
                            reader = csv.reader(csvfile, delimiter=',')
                            for x, row in enumerate(reader):
                                for y, tile in enumerate(row):
                                    world_data[x][y] = int(tile)
                        world = World()
                        player, health_bar = world.process_data(world_data)
                        boss_battle = False
                        current_question = random.randint(0, 22)
                        player_answer = ""
                        show_result_timer = 0
                        question_result = ""

        if editor_mode:
            # scroll map
            if scroll_left and bg_scroll > 0:
                bg_scroll -= scroll_speed

            if scroll_right and bg_scroll < (COLS * TILE_SIZE) - SCREEN_WIDTH:
                bg_scroll += scroll_speed

            # mouse position
            pos = pygame.mouse.get_pos()
            x = (pos[0] + bg_scroll) // TILE_SIZE
            y = pos[1] // TILE_SIZE

            # place tile
            if pos[0] < SCREEN_WIDTH and pos[1] < SCREEN_HEIGHT:
                if pygame.mouse.get_pressed()[0]:
                    world_data[round(y)][round(x)] = current_tile

                # remove tile
                if pygame.mouse.get_pressed()[2]:
                    world_data[round(y)][round(x)] = -1

        for event in pygame.event.get():
            # quit game
            if event.type == pygame.QUIT:
                run = False
            # keyboard presses
            if event.type == pygame.KEYDOWN:
                if boss_battle:

                    if event.key == pygame.K_RETURN:

                        correct_answer = questions[current_question]["answer"]

                        if player_answer.lower() == correct_answer.lower():

                            question_result = "Correct!"

                            current_question = random.randint(0, 22)
                            correctly_answered += 1

                            if correctly_answered >= num_of_questions:

                                question_result = "Boss Defeated!"

                                for boss in boss_group:
                                    boss.defeated = True
                                    boss.kill()

                                boss_battle = False
                                current_question = random.randint(0, 22)
                                correctly_answered = 0
                                num_of_questions += 5

                        else:
                            question_result = "Wrong Answer! -20 Health"
                            player.health -= 20

                        player_answer = ""
                        show_result_timer = 120

                    elif event.key == pygame.K_BACKSPACE:
                        player_answer = player_answer[:-1]

                    else:
                        player_answer += event.unicode

                    continue
                if event.key == pygame.K_a and (not editor_mode):
                    moving_left = True
                if event.key == pygame.K_d and (not editor_mode):
                    moving_right = True
                if event.key == pygame.K_SPACE:
                    shoot = True
                if event.key == pygame.K_q:
                    grenade = True
                if event.key == pygame.K_w and player.alive:

                    if player.climbing:
                        moving_up = True
                    else:
                        player.jump = True
                        jump_fx.play()
                if event.key == pygame.K_s:

                    if editor_mode:
                        save_level(world_data, level)

                    else:
                        moving_down = True
                if event.key == pygame.K_ESCAPE:
                    run = False

                if event.key == pygame.K_e:
                    editor_mode = not editor_mode

                    if not editor_mode:
                        world = World()
                        player, health_bar = world.process_data(world_data)
                        boss_battle = False
                        current_question = random.randint(0, 22)
                        player_answer = ""
                        show_result_timer = 0
                        question_result = ""

                if editor_mode:
                    if event.key == pygame.K_LEFT:
                        scroll_left = True

                    if event.key == pygame.K_RIGHT:
                        scroll_right = True

                    if event.key == pygame.K_l:
                        world_data = load_level(level)

            # keyboard button released
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    moving_left = False
                if event.key == pygame.K_d:
                    moving_right = False
                if event.key == pygame.K_SPACE:
                    shoot = False
                if event.key == pygame.K_q:
                    grenade = False
                    grenade_thrown = False
                if event.key == pygame.K_w:
                    moving_up = False

                if event.key == pygame.K_s:
                    moving_down = False

                if event.key == pygame.K_LEFT:
                    scroll_left = False

                if event.key == pygame.K_RIGHT:
                    scroll_right = False

            if event.type == pygame.MOUSEWHEEL:

                if editor_mode:

                    palette_scroll -= event.y * PALETTE_SCROLL_SPEED

                    # clamp scrolling
                    max_scroll = max(
                        0,
                        ((TILE_TYPES // 3) * 45) - SCREEN_HEIGHT + 100
                    )

                    if palette_scroll < 0:
                        palette_scroll = 0

                    if palette_scroll > max_scroll:
                        palette_scroll = max_scroll

        pygame.display.update()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())