import pygame
import random

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction, alphabet_list, damage):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 15
        self.image = alphabet_list[random.randint(0, 26)]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.direction = direction
        self.damage = damage

    def update(self, screen_scroll, SCREEN_WIDTH, world, breakable_block_group, player, bullet_group, enemy_group, dt):
        # move bullet
        self.rect.x += (self.direction * self.speed * dt) + screen_scroll
        # check if bullet has gone off screen
        if self.rect.right < 0 or self.rect.left > SCREEN_WIDTH:
            self.kill()
        # check collision with level
        for tile in world.obstacle_list:
            if tile[1].colliderect(self.rect):
                self.kill()

        # breakable blocks collision
        for block in breakable_block_group:
            if block.rect.colliderect(self.rect):
                # remove matching obstacle tile
                for tile in world.obstacle_list:
                    if tile[1] == block.rect:
                        world.obstacle_list.remove(tile)
                        break

                block.kill()
                self.kill()
                break

        # check collision with characters
        if pygame.sprite.spritecollide(player, bullet_group, False):
            if player.alive:
                player.health -= self.damage
                self.kill()
        for enemy in enemy_group:
            if pygame.sprite.spritecollide(enemy, bullet_group, False):
                if enemy.alive:
                    enemy.health -= 25
                    self.kill()